<template>
  <section class="mx-auto max-w-md space-y-6">
    <div class="card">
      <div class="card-body space-y-3">
        <h1 class="text-2xl font-extrabold tracking-tight">Mot de passe oublié</h1>
        <p class="text-sm text-muted">
          Cette fonctionnalité sera activée après stabilisation du module Auth.
        </p>

        <NuxtLink to="/login" class="btn btn-primary w-full">
          Retour à la connexion
        </NuxtLink>
      </div>
    </div>
  </section>
</template>
