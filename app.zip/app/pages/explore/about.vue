<template>
    <div>
        Yenge About Page
    </div>
</template>