<template>
    <div>
        Yengen Features Page
    </div>
</template>