<template>
    <div>
        Yenge Pricing Page
    </div>
</template>