// server/utils/mailer.js
import nodemailer from 'nodemailer'
import { createError } from 'h3'
import { useRuntimeConfig } from '#imports'

let _transporter = null

function getAppUrl(config) {
  // on privilégie public.APP_URL (ton nuxt.config actuel)
  return (
    process.env.APP_URL ||
    config.public?.APP_URL ||
    config.APP_URL ||
    'http://localhost:3010'
  ).replace(/\/$/, '')
}

function getTransporter() {
  if (_transporter) return _transporter

  const config = useRuntimeConfig()

  const host = process.env.SMTP_HOST || config.SMTP_HOST
  const portRaw = process.env.SMTP_PORT || config.SMTP_PORT
  const port = Number(portRaw || 587)
  const user = process.env.SMTP_USER || config.SMTP_USER
  const pass = process.env.SMTP_PASS || config.SMTP_PASS

  // Mode dev : si pas configuré, on ne casse pas l’app
  if (!host || !user || !pass) {
    return null
  }

  const secure = port === 465 // 465 = SSL ; 587 = STARTTLS
  _transporter = nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
  })

  return _transporter
}

/**
 * sendEmail({ toEmail, toName, subject, html, text })
 */
export async function sendEmail({ toEmail, toName, subject, html, text }) {
  const config = useRuntimeConfig()

  const fromEmail = process.env.EMAIL_FROM || config.EMAIL_FROM
  const fromName = process.env.EMAIL_FROM_NAME || config.EMAIL_FROM_NAME || 'Les derniers léopards'

  if (!fromEmail) {
    throw createError({ statusCode: 500, statusMessage: 'EMAIL_FROM manquant (runtimeConfig).' })
  }

  // Option dev: rediriger toutes les sorties vers EMAIL_TO si défini
  const devTo = process.env.EMAIL_TO || config.EMAIL_TO
  const isProd = process.env.NODE_ENV === 'production'
  const finalTo = (!isProd && devTo) ? devTo : toEmail

  const transporter = getTransporter()

  // Mode dev : si SMTP non configuré, on log au lieu d’échouer
  if (!transporter) {
    console.log('[MAIL DEV] SMTP non configuré -> email simulé', {
      to: finalTo,
      subject,
    })
    return { ok: true, dev: true }
  }

  try {
    await transporter.sendMail({
      from: { name: fromName, address: fromEmail },
      to: [{ name: toName || finalTo, address: finalTo }],
      subject,
      text: text || undefined,
      html: html || undefined,
    })
    return { ok: true }
  } catch (err) {
    console.error('[MAIL ERROR]', err)
    throw createError({
      statusCode: 502,
      statusMessage: 'SMTP error: envoi email impossible.',
    })
  }
}

export async function sendVerifyEmail({ email, token }) {
  const config = useRuntimeConfig()
  const appUrl = getAppUrl(config)

  // Endpoint server (API) qui valide et redirige/affiche un message
  const url = `${appUrl}/api/auth/verify-email?token=${encodeURIComponent(token)}`

  return sendEmail({
    toEmail: email,
    subject: 'Confirme ton email — Les derniers léopards',
    text: `Confirme ton email : ${url}\nSi tu n’es pas à l’origine, ignore ce message.`,
    html: `
      <div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;line-height:1.5">
        <p>Salut,</p>
        <p>Confirme ton email en cliquant ici :</p>
        <p><a href="${url}">${url}</a></p>
        <p>Si tu n’es pas à l’origine de cette demande, ignore ce message.</p>
      </div>
    `,
  })
}

export async function sendResetPasswordEmail({ email, token }) {
  const config = useRuntimeConfig()
  const appUrl = getAppUrl(config)

  // Page front (reset)
  const url = `${appUrl}/reset-password?token=${encodeURIComponent(token)}`

  return sendEmail({
    toEmail: email,
    subject: 'Réinitialise ton mot de passe — Les derniers léopards',
    text: `Réinitialise ton mot de passe : ${url}\nSi tu n’as pas demandé ça, ignore ce message.`,
    html: `
      <div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;line-height:1.5">
        <p>Salut,</p>
        <p>Pour réinitialiser ton mot de passe :</p>
        <p><a href="${url}">${url}</a></p>
        <p>Si tu n’as pas demandé ça, ignore ce message.</p>
      </div>
    `,
  })
}
